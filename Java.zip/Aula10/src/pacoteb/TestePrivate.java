package pacoteb;

public class TestePrivate {
   public static void main(String args[]) {
	   ClassePrivate obj = new ClassePrivate();
	   obj.imprimeData();
   }
}
