package pacoteb;

public class ClassePrivate {
    private String data;
    
    public void imprimeData() {
    	data="10/10/2024";
    	System.out.println(data);
    }
    public static void main(String args[]) {
 	   ClassePrivate obj = new ClassePrivate();
 	   obj.imprimeData();
    }
}
