package pacoteb;

import pacotea.A;
public class TesteProtected {
   public static void main(String args[]) {
	   A obj= new A();
	   obj.soma();
   }
}
