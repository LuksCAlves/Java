package pacotea;

public class B {
   public static void main(String args[]) {
	   A obj=new A();   
	   obj.imprimirNome();
	   System.out.println(obj.nome);
   }//fim main
}
