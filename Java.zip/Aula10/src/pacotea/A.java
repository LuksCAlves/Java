package pacotea;

public class A {
     protected String nome;
     public int idade;
     
     
     protected void imprimirNome() {
    	 this.nome="Ana";
    	 System.out.println("Nome: + this.nome");
     }
     
     public void soma() {
    	 System.out.println(1+1);
     }
     protected void defineIdade() { 
    	 this.idade=20;
     }
}
