package Matriz;

public class teste2 {
	
	public static void main (String args[][]) {
		exemplo2 obj;
		obj = new exemplo2();
		aula1 obj2;
		obj2 = new aula1();
		int a[][] = 
			{
					{2, 4, 5},
					{3, 7, 9},
					{1, 6, 8}
					
			};
		
		int b [][] = 
			{
					{1, 2, 3},
					{4, 5, 6},
					{7, 8, 9}
			};
		int matriz [][] = obj. somaMatrizes(a, b);
		obj2.imprimirMatrizInteiro(matriz);
	
		
	} //fim main
}//fim class
