package Matriz;

public class exemplo2 {

	public int[][] somaMatrizes(int [][]A, int [][]B){
		int matrizResultado[][] = new int [A.length][A[0].length];
		for(int linha=0; linha<A.length; linha++) {
			for(int coluna =0; coluna <A[0].length; coluna++) {
				matrizResultado [linha][coluna]= A [linha][coluna] + B[linha][coluna];
			
								
			}//fim for coluna
			}//fim for linha
		
		return matrizResultado;
		
	}//fim metodo
	
	
} //fim class
