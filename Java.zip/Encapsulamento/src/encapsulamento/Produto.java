package encapsulamento;

public class Produto {
	private String nome;
	private int quantidade;
	private double preco;
	
	public Produto(String nomeP, int qtdP, double precoP) {
		this.nome= nomeP;
		setQuantidade(qtdP);
		setPreco(precoP);
	}//fim construtor
	
	public void setNome(String nome) {
		this.nome= nome;
	}
	public String getNome() {
		return this.nome;
	}
	
	public void setQuantidade(int qtd) {
		
	}//fim metodo

}//fim class
