package encapsulamento;

import java.util.Scanner;
public class TestContaBancaria {
	
	public static void main(String args[]) {
		Scanner entrada= new Scanner(System.in);
		System.out.print("Digite o titular da conta:");
		String nome= entrada.nextLine();
		System.out.print("Digite o saldo da conta:");
		double saldo = entrada.nextDouble();
		ContaBancaria obj = new ContaBancaria (nome, saldo);
		
		System.out.print("Digite o valor do depósito:");
		System.out.println(obj.deposito(entrada.nextDouble()));
		
		System.out.println("Saldo atualizaqdo:" + obj.getSaldo());
		
		System.out.print("Digite o valor do saque:");
		System.out.println(obj.saque(entrada.nextDouble()));
		System.out.println("Saldo atualizaqdo:" + obj.getSaldo());
		
		System.out.println("Nome antigo:" + obj.getTitular());
		obj.setTitular("Fulano de tal");
		System.out.println("Nome atualizado:"+ obj.getTitular());
	}//fim main
}//fim class
