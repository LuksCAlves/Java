package encapsulamento;

public class ContaBancaria {
	private String titular;
	private double saldo;
	
	public ContaBancaria (String titular, double saldo) {
		this.titular= titular;
		if(saldo < 0) {
			this.saldo=0;
		}
		else {
			this.saldo=saldo;
		}
	}//fim construtor
	
	public void setTitular(String nomeT) {
		this.titular= nomeT;
	}
    public String getTitular() {
    	return this.titular;
    }
    
    public void setSaldo(double novoSaldo) {
    	this.saldo= novoSaldo;
    }//fim set
    
    public double getSaldo() {
    	return this.saldo;
    }
    
    public String saque(double valorSaque) {
    	if(valorSaque <= this.saldo) {
    		this.saldo= this.saldo - valorSaque;
    		return "Saque realizado com sucesso!";
    	}//fim if 
    	else {
    		return "Saldo insuficiente";
    	}//fim else	
    }//fim saldo
    
    public String deposito(double valorDeposito) {
    	if(valorDeposito >0) {
    		this.saldo= this.saldo + valorDeposito;
    		return "Depósito realizado com sucesso";
    	}//fim if 
    	else {
    		return "Não é possivel depositar valores <=0";
    	}//fim else
    }//fim deposito
}//fim class
