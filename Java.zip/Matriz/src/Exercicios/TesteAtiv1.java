package Exercicios;

public class TesteAtiv1 {
    public static void main(String[] args) {
        Ativ1 atividade1 = new Ativ1();
        atividade1.atividade1();
    }
}
