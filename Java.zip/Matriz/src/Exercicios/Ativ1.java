package Exercicios;

import java.util.Scanner;

public class Ativ1 {
    public void atividade1() {
        Scanner scanner = new Scanner(System.in);
        int[][] matriz = new int[4][4];
        int contador = 0;

        for (int i = 0; i < 4; i++) {
            for (int j = 0; j < 4; j++) {
                System.out.print("Digite o elemento [" + i + "][" + j + "]: ");
                matriz[i][j] = scanner.nextInt();
                if (matriz[i][j] > 10) {
                    contador++;
                }
            }
        }
        System.out.println("Quantidade de valores maiores que 10: " + contador);
    }
}
