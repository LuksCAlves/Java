package herança;

public class Animal {
	private String nome;
	public Animal(String s) {
		this.nome=s;
	}// fim construtor
	
	public void setNome(String a) {
		this.nome=a;
	}
	public String getNome() {
		return this.nome;
	}
	public void emitirSom() {
		System.out.println("Emitir som!");
	}
}//fim classe
