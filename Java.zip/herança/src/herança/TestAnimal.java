package herança;

public class TestAnimal {
	public static void main(String args[]) {
		Animal animal= new Animal("Lobo");
		Cachorro cachorro= new Cachorro("Bily");
		Gato gato=  new Gato("Garfield");
		
		animal.emitirSom();
		cachorro.emitirSom();
		gato.emitirSom();
	}

}//fim class
