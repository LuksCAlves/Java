package herança;

public class Cachorro extends Animal{
	
	public Cachorro(String nome) {
		super(nome);
	}//fim construtor
	public void emitirSom() {
		System.out.println(super.getNome()+" está latindo!!");
	}

}//fim class
