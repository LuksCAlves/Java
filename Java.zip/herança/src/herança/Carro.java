package herança;

public class Carro extends Veiculo{
	public Carro(String cor, int vMax) {
		super(cor, vMax);
		}
	
	public void acelerar() {
		String out="Carro acelerando de ";
		for(int i=0; i< super.getVelocidadeMaxima(); i++) {
			out += i+ " ";
		}//fim for
		System.out.println(out);
	}

}//fim class
