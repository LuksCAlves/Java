package herança;

public class Gato extends Animal {
	
	public Gato(String nome) {
		super(nome);
	}
	public void emitirSom() {
		System.out.println(super.getNome()+" está miando!!");
	}

}//fim class
