package herança;

public class TestVeiculo {
	public static void main(String args[]) {
		Carro carro= new Carro("branco", 240);
		Moto moto= new Moto(180,"verde");
		carro.exibirInfo();
		System.out.println();
		moto.exibirInfo();
		System.out.println();
		carro.acelerar();
		System.out.println();
		moto.acelerar();
	}

}//fim class
