package herança;

public class Moto extends Veiculo {
	
	public Moto(int veMax, String cor) {
		super(cor, veMax); 
	}
	public void acelerar() {
		String out="Moto acelerando: ";
		for(int i=0; i<super.getVelocidadeMaxima(); i++) {
			out += i+ " ";
		}//fim for
		System.out.println(out);
	}

}
