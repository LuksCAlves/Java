package herança;

public class Veiculo {
	private String cor;
	private int velocidadeMaxima;
	public Veiculo(String cor, int velocidade) {
		this.cor= cor;
		this.setVelocidadeMaxima(velocidade);
	}
	public void setVelocidadeMaxima(int velocidadeMax) {
		if(velocidadeMax<0) {
			this.velocidadeMaxima=0;
		}
		else {
			this.velocidadeMaxima=velocidadeMax;
		}
	}//fim set
	public String getCor() {
		return this.cor;
	}
	public int getVelocidadeMaxima() {
		return this.velocidadeMaxima;
	}
	public void exibirInfo() {
		System.out.println("***********\n"
				             +"cor;"+this.cor+"\n"
				             +"Velocidade:"+this.velocidadeMaxima+"\n"+
				             "***********");
	}
	public void acelerar() {
		String out="Veiculo acelerando de ";
		for(int i=0; i<this.velocidadeMaxima; i++) {
			out += i+ " ";
		}//fim for
		System.out.println(out);
	}

}//fim class
