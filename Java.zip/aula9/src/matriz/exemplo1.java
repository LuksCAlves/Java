package matriz;

import java.util.Scanner;

public class exemplo1 {
	public void matrizInicializada() {
//Aqui se declara a matriz
//As linhas e colunas na matriz sempre começam por 0
		int mat[][]= {
//E os valores fixos
				{1, 2, 3},
				{4, 5, 6},
				{7, 8, 9}
		};
//Aqui para mostrar o valor conforme a linha e a coluna
//O primeiro valor em matriz sempre vai ser a linha e depois a coluna
//Nesse caso vai aparecer 4
//Tá pedindo a linha 1 coluna 0
		System.out.println(mat[1][0]);
//Nesse caso vai aparecer 9
		System.out.println(mat[2][2]);
	    System.out.println("***imprimindo toda a matriz***");
//Aqui é para percorrer todas as colunas usando for
//Aqui varrer colunas de cada linha usando for
	    for(int linha=0; linha < mat.length; linha++) {
	    	for(int coluna=0; coluna < mat[0].length; coluna++) 
	    	{
	    		System.out.print(mat[linha] [coluna]+" ");
	    	}//fim for
	    	    System.out.println();
	    }//fim for
	}//fim método
//l para linhas e c para colunas
	public void escreveMatriz(int l, int c) {
//Aqui declara uma variável de matriz no caso "valores"
		double valores[][] = new double[l][c];
//Scanner para trabalhar com entrada de usuários
		Scanner entrada= new Scanner(System.in);
		for(int linha=0; linha < valores.length; linha++) {
			for(int coluna=0; coluna < valores[0].length; coluna++) {
				System.out.print("Digite o valor [" +linha+ "] " + "[" +coluna+ "]:");
				valores[linha][coluna]= entrada.nextDouble();
			}//fim for esse percorre as colunas
		}//fim for esse for vai percorrer as linhas
//Faz referência a tudo que você escreveu na classe nesse caso a classe exemplo1
				this.imprimirMatriz(valores);
	}//fim método
	public void imprimirMatriz(double matriz[][]) {
		System.out.println("***Imprimir matriz de valores***");
		for(int linha=0; linha < matriz.length; linha++) {
			for(int coluna=0; coluna < matriz[0].length; coluna++) {
				System.out.print(matriz[linha][coluna]+" ");
			}//fim for coluna
			System.out.println();
		}//fim for linha
	}//fim método
}//fim class
