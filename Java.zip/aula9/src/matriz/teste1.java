package matriz;

public class teste1 {
	public static void main(String args[]) {
		exemplo1 obj;
		obj= new exemplo1();
		obj.matrizInicializada();
		obj.escreveMatriz(2, 2);
	}//fim main
}//fim class
